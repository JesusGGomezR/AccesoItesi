<div class="center-word">
    <div class="page-header">
        <h1>Correo electrónico enviado con éxito.</h1>
    </div>
    <div class="alert alert-info" role="alert">
        ¡Gracias! Por favor revise su bandeja de entrada.
        <br>
        Login? <a href="<?php echo base_url() . 'main/login' ?>">login</a>
    </div>
</div>