<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Report extends CI_Controller
{

    public $status;
    public $roles;

    /**
     * Cree una nueva instancia de controlador.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MainModel', 'MainModel', TRUE);
        $this->load->model('ReportModel', 'ReportModel', TRUE);
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->status = $this->config->item('status');
        $this->roles = $this->config->item('roles');
        $this->load->library('userlevel');
    }

    /**
     * Ver página de informe de índice.
     *
     * @return void
     */
    public function index()
    {
        $data = $this->session->userdata;

        //checa el nivel de usuario
        if (empty($data['role'])) {
            redirect(site_url() . 'main/login/');
        }

        $dataLevel = $this->userlevel->checkLevel($data['role']);
        //checa el nivel de usuario

        $dataInfo = array(
            'id' => $data['id']
        );
        $data['title'] = 'Report';
        $resultGetUser = $this->MainModel->getUserInfo($dataInfo['id']);
        $data['name'] = $resultGetUser->first_name . ' ' . $resultGetUser->last_name  . '  ' .  $resultGetUser->no_control . ' ' . $resultGetUser->carrera . ' ' . $resultGetUser->semestre;
       

        // Cargar js
        $data['js_to_load'] = array(
            'bootstrap-datepicker.min.js',
            'jquery.dataTables.min.js',
            'dataTables.buttons.min.js',
            'buttons.flash.min.js',
            'jszip.min.js',
            'pdfmake.min.js',
            'vfs_fonts.js',
            'buttons.html5.min.js',
            'buttons.print.min.js',
            'dataTables.bootstrap.min.js',
            'report/index.js'
        );

        // Agrega datos para que js llame a ajax
        $data['data_js'] = array(
            'var role = ' . $data['role'] . ';',
            'var name = "' . $data['first_name'] . ' ' . $data['last_name'] . ' ' .$data['no_control'] . ' ' . $data['semestre'] . ' ' . $data['carrera'] . '";',
        );

        if ($dataLevel == 'is_admin' || $dataLevel == 'is_user') {
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('template/container');
            $this->load->view('report/report', $data);
            $this->load->view('template/footer', $data);
        } else {
            redirect(site_url() . 'main/');
        }

    }

    /**
     * Obtiene tablas de datos.
     *
     * @return void
     */
    public function dataTableJson()
    {
        // Obtener rol y nombre
        $role = $this->input->post('role');
        $name = $this->input->post('name');
        $no_control = $this->input->post('no_control');

        $data = array(
            'role' => $role,
            'name' => $name,
            'no_control' => $no_control,
        );

        echo $this->ReportModel->getDataTables($data);
    }
}