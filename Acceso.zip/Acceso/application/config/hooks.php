<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Manos
| -------------------------------------------------- -----------------------
| Este archivo le permite definir "ganchos" para extender CI sin piratear el núcleo
| archivos Consulte la guía del usuario para obtener información:
|
|	https://codeigniter.com/user_guide/general/hooks.html
|
*/

// comprimir salida
$hook['display_override'][] = array(
    'class' => '',
    'function' => 'compress',
    'filename' => 'compress.php',
    'filepath' => 'hooks'
);
