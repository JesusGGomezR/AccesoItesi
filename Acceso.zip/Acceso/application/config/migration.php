<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Habilitar/deshabilitar migraciones
|----------------------------------------------------------------- -------------------------
|
| Las migraciones están deshabilitadas de forma predeterminada por razones de seguridad.
| Debe habilitar las migraciones siempre que tenga la intención de realizar una migración de esquema
| y desactívelo cuando haya terminado.
|
*/
$config['migration_enabled'] = FALSE;

/*
|--------------------------------------------------------------------------
| Tipo de migración
|----------------------------------------------------------------- -------------------------
|
| Los nombres de los archivos de migración pueden basarse en un identificador secuencial o en
| una marca de tiempo Las opciones son:
|
|   'sequential' = Denominación de migración secuencial (001_add_blog.php)
|   'timestamp'  = Nomenclatura de migración de marca de tiempo (20121031104401_add_blog.php)
|                  Utilice el formato de marca de tiempo AAAAMMDDHIISS.
|
| Nota: si falta este valor de configuración, la biblioteca de migración
| el valor predeterminado es 'secuencial' para compatibilidad con versiones anteriores de CI2.
|
*/
$config['migration_type'] = 'timestamp';

/*
|--------------------------------------------------------------------------
| Tabla de migraciones
|----------------------------------------------------------------- -------------------------
|
| Este es el nombre de la tabla que almacenará el estado actual de las migraciones.
| Cuando se ejecuta la migración, se almacenará en una tabla de base de datos qué migración
| nivel en el que se encuentra el sistema. Luego compara el nivel de migración en este
| table a $config['migration_version'] si no son lo mismo
| migrará hacia arriba. Esto debe configurarse.
|
*/
$config['migration_table'] = 'migrations';

/*
|--------------------------------------------------------------------------
| Migración automática a la última
|----------------------------------------------------------------- -------------------------
|
| Si esto se establece en TRUE cuando carga la clase de migraciones y tiene
| $config['migration_enabled'] establecido en TRUE, el sistema migrará automáticamente
| a su última migración (cualquiera que sea $config['migration_version']
| ajustado a). Así no tienes que llamar a migraciones a ningún otro lado
| en su código para tener la última migración.
|
*/
$config['migration_auto_latest'] = FALSE;

/*
|--------------------------------------------------------------------------
| Versión de migraciones
|----------------------------------------------------------------- -------------------------
|
| Esto se usa para establecer la versión de migración en la que debe estar el sistema de archivos.
| Si ejecuta $this->migration->current(), esta es la versión que tendrá el esquema
| ser actualizado / degradado a.
|
*/
$config['migration_version'] = 0;

/*
|--------------------------------------------------------------------------
| Ruta de migraciones
|----------------------------------------------------------------- -------------------------
|
| Ruta a su carpeta de migraciones.
| Por lo general, estará dentro de la ruta de su aplicación.
| Además, se requiere permiso de escritura dentro de la ruta de migración.
|
*/
$config['migration_path'] = APPPATH . 'migrations/';
