<div class="container">
    <h2>Usuarios</h2>
    <hr>

    <div class="table-responsive">
        <table id="data-table">
            <thead>
                <tr>
                    <th>
                        No.
                    </th>
                    <th>
                        Nombres
                    </th>
                    <th>
                        Apellido
                    </th>
                       <th>
                        no. control
                    </th>
                       <th>
                        carrera
                    </th>
                       <th>
                        Correo
                    </th>
                    <th>
                        Semestre 
                    </th>
                    <th>
                        Ultimo acceso
                    </th>
                    <th>
                        Rol
                    </th>
                    <th>
                        Estado
                    </th>
                    <th>
                        Prohibicion
                    </th>
                    <th>
                        Accion
                    </th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <p>
        <b>*Nota</b> : <br>
        Estado "pendiente" significa que el usuario no verifica su correo electrónico.
    </p>
</div>

</div><!--row-->
