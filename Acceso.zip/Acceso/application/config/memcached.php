<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Configuración de Memcached
| -------------------------------------------------- -----------------------
| Sus servidores Memcached se pueden especificar a continuación.
|
|	Ver: https://codeigniter.com/user_guide/libraries/caching.html#memcached
|
*/
$config = array(
    'default' => array(
        'hostname' => '127.0.0.1',
        'port' => '11211',
        'weight' => '1',
    ),
);
