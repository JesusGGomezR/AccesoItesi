<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| ENRUTAMIENTO URI
| -------------------------------------------------- -----------------------
| Este archivo le permite reasignar solicitudes de URI a funciones de controlador específicas.
|
| Por lo general, existe una relación de uno a uno entre una cadena de URL
| y su clase/método de controlador correspondiente. Los segmentos en un
| La URL normalmente sigue este patrón:
|
|	example.com/class/method/id/
|
| En algunos casos, sin embargo, es posible que desee reasignar esta relación
| para que se llame a una clase/función diferente a la
| correspondiente a la URL.
|
| Consulte la guía del usuario para obtener detalles completos:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RUTAS RESERVADAS
| -------------------------------------------------- -----------------------
|
| Hay tres rutas reservadas:
|
|	$route['default_controller'] = 'welcome';
|
| Esta ruta indica qué clase de controlador debe cargarse si el
| URI no contiene datos. En el ejemplo anterior, la clase "bienvenida"
| estaría cargado.
|
|	$route['404_override'] = 'errors/page_missing';
|
|   Esta ruta le dirá al enrutador qué controlador/método usar si esos
|   proporcionada en la URL no puede coincidir con una ruta válida.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| Esto no es exactamente una ruta, pero le permite enrutar automáticamente
| nombres de métodos y controladores que contienen guiones. '-' no es válido
| carácter de nombre de clase o método, por lo que requiere traducción.
| Cuando establece esta opción en VERDADERO, reemplazará TODOS los guiones en el
| Segmentos URI de controlador y método.
|
| Ejemplos:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'main';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['employee/(:num)'] = 'main/employee/$1';
