<hr>
Copyright&copy; - <?php echo date('Y'); ?> | Creado por Ing. Sistemas Computacionales</a>
</div>
</div>
</div><!--row-->
</div><!-- /contenedor -->


<!-- /Cargar Js -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js" type="text/javascript"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>