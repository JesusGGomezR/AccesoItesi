<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Password
{

    /*
     * Hashing de contraseñas con PBKDF2.
     * Autor: havoc AT defuse.ca
     * www: https://defuse.ca/php-pbkdf2.htm
     *
     * Portado a CodeIgniter por Richard Thornton
     * http://www.richardthornton.com
     * http://twitter.com/RichardThornton
     */

    // Estas constantes se pueden cambiar sin romper los hashes existentes.

    const PBKDF2_HASH_ALGORITHM = 'sha256';
    const PBKDF2_ITERATIONS = 1000;
    const PBKDF2_SALT_BYTE_SIZE = 24;
    const PBKDF2_HASH_BYTE_SIZE = 24;

    const HASH_SECTIONS = 4;
    const HASH_ALGORITHM_INDEX = 0;
    const HASH_ITERATION_INDEX = 1;
    const HASH_SALT_INDEX = 2;
    const HASH_PBKDF2_INDEX = 3;

    function create_hash($password)
    {
        // formato: algoritmo:iteraciones:sal:hash
        $salt = base64_encode(password_hash(self::PBKDF2_SALT_BYTE_SIZE, PASSWORD_BCRYPT));
        return self::PBKDF2_HASH_ALGORITHM . ":" . self::PBKDF2_ITERATIONS . ":" . $salt . ":" .
            base64_encode($this->pbkdf2(
                self::PBKDF2_HASH_ALGORITHM,
                $password,
                $salt,
                self::PBKDF2_ITERATIONS,
                self::PBKDF2_HASH_BYTE_SIZE,
                true
            ));
    }

    function pbkdf2($algorithm, $password, $salt, $count, $key_length, $raw_output = false)
    {
        $algorithm = strtolower($algorithm);
        if (!in_array($algorithm, hash_algos(), true))
            die('PBKDF2 ERROR: Invalid hash algorithm.');
        if ($count <= 0 || $key_length <= 0)
            die('PBKDF2 ERROR: Invalid parameters.');

        $hash_length = strlen(hash($algorithm, "", true));
        $block_count = ceil($key_length / $hash_length);

        $output = "";
        for ($i = 1; $i <= $block_count; $i++) {
            // $i codificado como 4 bytes, extremo grande.
            $last = $salt . pack("N", $i);
            // first iteration
            $last = $xorsum = hash_hmac($algorithm, $last, $password, true);
            // realiza el otro $count - 1 iteraciones
            for ($j = 1; $j < $count; $j++) {
                $xorsum ^= ($last = hash_hmac($algorithm, $last, $password, true));
            }
            $output .= $xorsum;
        }

        if ($raw_output)
            return substr($output, 0, $key_length);
        else
            return bin2hex(substr($output, 0, $key_length));
    }

    // Compara dos cadenas $a y $b en tiempo constante de longitud.

    function validate_password($password, $correct_hash)
    {
        $params = explode(":", $correct_hash);
        if (count($params) < self::HASH_SECTIONS)
            return false;
        $pbkdf2 = base64_decode($params[self::HASH_PBKDF2_INDEX]);
        return $this->slow_equals(
            $pbkdf2,
            $this->pbkdf2(
                $params[self::HASH_ALGORITHM_INDEX],
                $password,
                $params[self::HASH_SALT_INDEX],
                (int)$params[self::HASH_ITERATION_INDEX],
                strlen($pbkdf2),
                true
            )
        );
    }

    /*
     * Función de derivación de clave PBKDF2 según lo definido por PKCS #5 de RSA: https://www.ietf.org/rfc/rfc2898.txt
     * $algorithm - El algoritmo hash a utilizar. Recomendado: SHA256
     * $password - La contraseña.
     * $salt - Un salt que es única para la contraseña.
     * $count - Recuento de iteraciones. Más alto es mejor, pero más lento. Recomendado: Al menos 1000.
     * $key_length - La longitud de la clave derivada en bytes.
     * $raw_output - Si es verdadero, la clave se devuelve en formato binario sin procesar. Codificación hexadecimal de lo contrario.
     * Returns: Una $key_length-byte clave derivada de la contraseña y salt.
     *
     * Los vectores de prueba se pueden encontrar aquí: https://www.ietf.org/rfc/rfc6070.txt
     *
     * Esta implementación de PBKDF2 fue creada originalmente por https://defuse.ca
     * Con mejoras por http://www.variations-of-shadow.com
     */

    function slow_equals($a, $b)
    {
        $diff = strlen($a) ^ strlen($b);
        for ($i = 0; $i < strlen($a) && $i < strlen($b); $i++) {
            $diff |= ord($a[$i]) ^ ord($b[$i]);
        }
        return $diff === 0;
    }

}
