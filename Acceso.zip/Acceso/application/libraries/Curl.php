<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * CodeIgniter Curl Clase
 *
 * Trabaje con servidores remotos a través de cURL mucho más fácil que usar los enlaces nativos de PHP.
 *
 * @package            CodeIgniter
 * @subpackage        Librerias
 * @category        Librerias
 * @author            Philip Sturgeon
 * @license         http://philsturgeon.co.uk/code/dbad-license
 * @link            http://philsturgeon.co.uk/code/codeigniter-curl
 */
class Curl
{

    public $error_code;                 // Instancia de CodeIgniter
    public $error_string;       // Contiene la respuesta cURL para la depuración.
    public $info;             // Contiene el controlador cURL para una sesión.
    protected $_ci;                 // URL de la sesión
    protected $response = '';   // Rellena curl_setopt_array
    protected $session;   // Rellena encabezados HTTP adicionales
    protected $url;             // Código de error devuelto como un int
    protected $options = array();           // Mensaje de error devuelto como una cadena
    protected $headers = array();                   //Devuelto después de la solicitud (tiempo transcurrido, etc.)

    function __construct($url = '')
    {
        $this->_ci = &get_instance();
        log_message('debug', 'cURL Class Initialized');

        if (!$this->is_enabled()) {
            log_message('error', 'cURL Class - PHP was not built with cURL enabled. Rebuild PHP with --with-curl to use cURL.');
        }

        $url and $this->create($url);
    }

    public function is_enabled()
    {
        return function_exists('curl_init');
    }

    /* =================================================================================
     * MÉTODOS SIMPLES
     * Con estos métodos, puede realizar una llamada cURL rápida y fácil con una línea.
     * ================================================================================= */

    public function create($url)
    {
        // Si no hay un protocolo en la URL, asuma que es un enlace CI
        if (!preg_match('!^\w+://! i', $url)) {
            $this->_ci->load->helper('url');
            $url = site_url($url);
        }

        $this->url = $url;
        $this->session = curl_init($this->url);

        return $this;
    }

    public function __call($method, $arguments)
    {
        if (in_array($method, array('simple_get', 'simple_post', 'simple_put', 'simple_delete', 'simple_patch'))) {
            //Quitar el "simple_" y pase get/post/put/delete/patch a _simple_call
            $verb = str_replace('simple_', '', $method);
            array_unshift($arguments, $verb);
            return call_user_func_array(array($this, '_simple_call'), $arguments);
        }
    }

    /* =================================================================================
     * MÉTODOS AVANZADOS
     * Utilice estos métodos para crear consultas más complejas
     * ================================================================================= */

    public function _simple_call($method, $url, $params = array(), $options = array())
    {
        // Obtener actúa de manera diferente, ya que no acepta parámetros de la misma manera
        if ($method === 'get') {
            // Si se proporciona una URL, cree una nueva sesión
            $this->create($url . ($params ? '?' . http_build_query($params, NULL, '&') : ''));
        } else {
            // Si se proporciona una URL, cree una nueva sesión
            $this->create($url);

            $this->{$method}($params);
        }

        // Agregue las opciones específicas provistas
        $this->options($options);

        return $this->execute();
    }

    public function options($options = array())
    {
        // Combinar opciones con el resto: hecho como array_merge() no sobrescribe las teclas numéricas
        foreach ($options as $option_code => $option_value) {
            $this->option($option_code, $option_value);
        }

        // Establecer todas las opciones proporcionadas
        curl_setopt_array($this->session, $this->options);

        return $this;
    }

    public function option($code, $value, $prefix = 'opt')
    {
        if (is_string($code) && !is_numeric($code)) {
            $code = constant('CURL' . strtoupper($prefix) . '_' . strtoupper($code));
        }

        $this->options[$code] = $value;
        return $this;
    }

    public function execute()
    {
        // Establezca dos opciones predeterminadas y combine las adicionales en
        if (!isset($this->options[CURLOPT_TIMEOUT])) {
            $this->options[CURLOPT_TIMEOUT] = 30;
        }
        if (!isset($this->options[CURLOPT_RETURNTRANSFER])) {
            $this->options[CURLOPT_RETURNTRANSFER] = TRUE;
        }
        if (!isset($this->options[CURLOPT_FAILONERROR])) {
            $this->options[CURLOPT_FAILONERROR] = TRUE;
        }

        // Establezca solo la ubicación de seguimiento si no se ejecuta de forma segura
        if (!ini_get('safe_mode') && !ini_get('open_basedir')) {
            //Ok, la ubicación de seguimiento aún no está configurada, así que configurémosla en verdadero
            if (!isset($this->options[CURLOPT_FOLLOWLOCATION])) {
                $this->options[CURLOPT_FOLLOWLOCATION] = TRUE;
            }
        }

        if (!empty($this->headers)) {
            $this->option(CURLOPT_HTTPHEADER, $this->headers);
        }

        $this->options();

        // Ejecute la solicitud y oculte toda la salida
        $this->response = curl_exec($this->session);
        $this->info = curl_getinfo($this->session);

        // Solicitud fallida
        if ($this->response === FALSE) {
            $errno = curl_errno($this->session);
            $error = curl_error($this->session);

            curl_close($this->session);
            $this->set_defaults();

            $this->error_code = $errno;
            $this->error_string = $error;

            return FALSE;
        } // Solicitud exitosa
        else {
            curl_close($this->session);
            $this->last_response = $this->response;
            $this->set_defaults();
            return $this->last_response;
        }
    }

    public function set_defaults()
    {
        $this->response = '';
        $this->headers = array();
        $this->options = array();
        $this->error_code = NULL;
        $this->error_string = '';
        $this->session = NULL;
    }

    public function simple_ftp_get($url, $file_path, $username = '', $password = '')
    {
        // Si no hay ftp:// o ningún protocolo ingresado, agrega ftp://
        if (!preg_match('!^(ftp|sftp)://! i', $url)) {
            $url = 'ftp://' . $url;
        }

        // Usar un inicio de sesión FTP
        if ($username != '') {
            $auth_string = $username;

            if ($password != '') {
                $auth_string .= ':' . $password;
            }

            // Agregue la cadena de autenticación del usuario después del protocolo
            $url = str_replace('://', '://' . $auth_string . '@', $url);
        }

        // Agregar la ruta del archivo
        $url .= $file_path;

        $this->option(CURLOPT_BINARYTRANSFER, TRUE);
        $this->option(CURLOPT_VERBOSE, TRUE);

        return $this->execute();
    }

    public function post($params = array(), $options = array())
    {
        // Si es una matriz (en lugar de una cadena de consulta), formatéela correctamente
        if (is_array($params)) {
            $params = http_build_query($params, NULL, '&');
        }

        // Agregue las opciones específicas provistas
        $this->options($options);

        $this->http_method('post');

        $this->option(CURLOPT_POST, TRUE);
        $this->option(CURLOPT_POSTFIELDS, $params);
    }

    public function http_method($method)
    {
        $this->options[CURLOPT_CUSTOMREQUEST] = strtoupper($method);
        return $this;
    }

    public function put($params = array(), $options = array())
    {
        // Si es una matriz (en lugar de una cadena de consulta), formatéela correctamente
        if (is_array($params)) {
            $params = http_build_query($params, NULL, '&');
        }

        // Agregue las opciones específicas provistas
        $this->options($options);

        $this->http_method('put');
        $this->option(CURLOPT_POSTFIELDS, $params);

        // Método de anulación,  esto anula $_POST con datos PUT.
        $this->option(CURLOPT_HTTPHEADER, array('X-HTTP-Method-Override: PUT'));
    }

    public function patch($params = array(), $options = array())
    {
        // Si es una matriz (en lugar de una cadena de consulta), formatéela correctamente
        if (is_array($params)) {
            $params = http_build_query($params, NULL, '&');
        }

        // Agregue las opciones específicas provistas
        $this->options($options);

        $this->http_method('patch');
        $this->option(CURLOPT_POSTFIELDS, $params);

        // Método de anulación, esto anula $_POST con datos PATCH.
        $this->option(CURLOPT_HTTPHEADER, array('X-HTTP-Method-Override: PATCH'));
    }

    public function delete($params, $options = array())
    {
        // Si es una matriz (en lugar de una cadena de consulta), formatéela correctamente
        if (is_array($params)) {
            $params = http_build_query($params, NULL, '&');
        }

        // Agregue las opciones específicas provistas
        $this->options($options);

        $this->http_method('delete');

        $this->option(CURLOPT_POSTFIELDS, $params);
    }

    public function set_cookies($params = array())
    {
        if (is_array($params)) {
            $params = http_build_query($params, NULL, '&');
        }

        $this->option(CURLOPT_COOKIE, $params);
        return $this;
    }

    public function http_header($header, $content = NULL)
    {
        $this->headers[] = $content ? $header . ': ' . $content : $header;
        return $this;
    }

    // Iniciar una sesión desde una URL

    public function http_login($username = '', $password = '', $type = 'any')
    {
        $this->option(CURLOPT_HTTPAUTH, constant('CURLAUTH_' . strtoupper($type)));
        $this->option(CURLOPT_USERPWD, $username . ':' . $password);
        return $this;
    }

    // Finalizar una sesión y devolver los resultados

    public function proxy($url = '', $port = 80)
    {
        $this->option(CURLOPT_HTTPPROXYTUNNEL, TRUE);
        $this->option(CURLOPT_PROXY, $url . ':' . $port);
        return $this;
    }

    public function proxy_login($username = '', $password = '')
    {
        $this->option(CURLOPT_PROXYUSERPWD, $username . ':' . $password);
        return $this;
    }

    public function ssl($verify_peer = TRUE, $verify_host = 2, $path_to_cert = NULL)
    {
        if ($verify_peer) {
            $this->option(CURLOPT_SSL_VERIFYPEER, TRUE);
            $this->option(CURLOPT_SSL_VERIFYHOST, $verify_host);
            if (isset($path_to_cert)) {
                $path_to_cert = realpath($path_to_cert);
                $this->option(CURLOPT_CAINFO, $path_to_cert);
            }
        } else {
            $this->option(CURLOPT_SSL_VERIFYPEER, FALSE);
            $this->option(CURLOPT_SSL_VERIFYHOST, $verify_host);
        }
        return $this;
    }

    public function debug()
    {
        echo "=============================================<br/>\n";
        echo "<h2>CURL Test</h2>\n";
        echo "=============================================<br/>\n";
        echo "<h3>Response</h3>\n";
        echo "<code>" . nl2br(htmlentities($this->last_response)) . "</code><br/>\n\n";

        if ($this->error_string) {
            echo "=============================================<br/>\n";
            echo "<h3>Errors</h3>";
            echo "<strong>Code:</strong> " . $this->error_code . "<br/>\n";
            echo "<strong>Message:</strong> " . $this->error_string . "<br/>\n";
        }

        echo "=============================================<br/>\n";
        echo "<h3>Info</h3>";
        echo "<pre>";
        print_r($this->info);
        echo "</pre>";
    }

    public function debug_request()
    {
        return array(
            'url' => $this->url
        );
    }

}

/* Fin del archivo Curl.php */
/* Ubicacion: ./application/libraries/Curl.php */
