<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Comprimir pantalla HTML
| -------------------------------------------------------------------------
|
*/
function compress()
{
    $CI =& get_instance();
    $buffer = $CI->output->get_output();

    $search = array(
        '/\>[^\S ]+/s',
        '/[^\S ]+\</s',
        '/(\s)+/s', // acortar múltiples secuencias de espacios en blanco
        '#(?://)?<!\[CDATA\[(.*?)(?://)?\]\]>#s' //dejar CDATA solo
    );
    $replace = array(
        '>',
        '<',
        '\\1',
        "//&lt;![CDATA[\n" . '\1' . "\n//]]>"
    );

    $buffer = preg_replace($search, $replace, $buffer);

    $CI->output->set_output($buffer);
    $CI->output->_display();
}

/* Fin del archivo compress.php */
/* Localización: ./system/application/hools/compress.php */