<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Qr extends CI_Controller
{
    public $status;
    public $roles;

    /**
     * Cree una nueva instancia de controlador.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('QrModel', 'QrModel', TRUE);
        $this->load->model('MainModel', 'MainModel', TRUE);
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->status = $this->config->item('status');
        $this->roles = $this->config->item('roles');
        $this->load->library('userlevel');
    }

    /**
     * Ver generar página qr.
     *
     * @return void
     */
    public function generateQr()
    {
        $data = $this->session->userdata;

        //comprobar el nivel de usuario
        if (empty($data['role'])) {
            redirect(site_url() . 'main/login/');
        }
        $dataLevel = $this->userlevel->checkLevel($data['role']);
        //comprobar el nivel de usuario

        // Cargar el js
        $data['js_to_load'] = array(
            'qr/generate_qr.js'
        );

        //cheque es administrador o no
        if ($dataLevel == 'is_admin') {

            $data['title'] = 'Generate QR Code';
            $userDetails = $this->input->post('user-details');
            // generar el qr con datos de usuario
            if (!empty($userDetails) && $userDetails == 1) {

                $this->form_validation->set_rules('firstname', 'First Name', 'required');
                $this->form_validation->set_rules('lastname', 'Last Name', 'required');
                $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
                $this->form_validation->set_rules('role', 'role', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
                $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');

                $this->form_validation->set_rules('qr', 'Your Employee Full Name');

                if ($this->MainModel->isDuplicate($this->input->post('email'))) {
                    $this->session->set_flashdata('flash_message', 'User email already exists');
                    redirect(site_url() . 'qr/generateQr');
                } else {
                    $this->load->library('password');
                    $post = $this->input->post(NULL, TRUE);
                    $cleanPost = $this->security->xss_clean($post);
                    $cleanPost['qr'] = $this->input->post('firstname') . ' ' . $this->input->post('lastname') . ' ' . $this->input->post('no_control')
                    ;
               
                    $hashed = $this->password->create_hash($cleanPost['password']);

                    $cleanPost['email'] = $this->input->post('email');
                    $cleanPost['role'] = $this->input->post('role');
                    $cleanPost['first_name'] = $this->input->post('firstname');
                    $cleanPost['last_name'] = $this->input->post('lastname');
                    $cleanPost['no_control'] = $this->input->post('no_control');
                    $cleanPost['carrera'] = $this->input->post('carrera');
                    $cleanPost['semestre'] = $this->input->post('semestre');
                    $cleanPost['password'] = $hashed;
                    unset($cleanPost['passconf']);

                    $cleanPost['qr'] = $this->input->post('firstname') . ' ' . $this->input->post('lastname') . ' ' . $this->input->post('no_control') . ' ' . $this->input->post('carrera') . ' ' . $this->input->post('semestre');
                    $cleanPost['no'] = $this->input->post('no_control');
                    $cleanPost['carr'] = $this->input->post('carrera');
                    $cleanPost['sem'] = $this->input->post('semestre');
                    // Insertar en la base de datos
                    if (!$this->MainModel->addUser($cleanPost)) {
                        $this->session->set_flashdata('flash_message', 'There was a problem saving the QR.');
                        redirect(site_url() . 'qr/generateQr');
                    } else {
                        if (!$this->QrModel->insertQr($cleanPost)) {
                            $this->session->set_flashdata('flash_message', 'There was a problem saving the QR.');
                            redirect(site_url() . 'qr/generateQr');
                        } else {
                            $this->load->view('template/header', $data);
                            $this->load->view('template/navbar', $data);
                            $this->load->view('template/container');
                            $this->load->view('qr/generate_qr', $data, $cleanPost);
                            $this->load->view('template/footer', $data);
                        }
                    }
                }

            } else {
                $this->form_validation->set_rules('qr', 'Your Employee Full Name');
                if (empty($_POST)) {
                    $this->load->view('template/header', $data);
                    $this->load->view('template/navbar', $data);
                    $this->load->view('template/container');
                    $this->load->view('qr/generate_qr', $data);
                    $this->load->view('template/footer', $data);
                } else {
                    // Compruebe si hay algún nombre duplicado del código QR
                    if ($this->QrModel->isDuplicateQr($this->input->post('qr'))) {
                        $this->session->set_flashdata('flash_message', 'Name of user already exists. Please try another one.');
                        redirect(site_url() . 'qr/generateQr');
                    }

                    if ($this->input->post('qr') == '') {
                        $this->session->set_flashdata('flash_message', 'Please fill the name of user.');
                        redirect(site_url() . 'qr/generateQr');
                    }

                    $post = $this->input->post(NULL, TRUE);
                    $cleanPost = $this->security->xss_clean($post);
                    $cleanPost['qr'] = $this->input->post('qr');
                    $cleanPost['no'] = $this->input->post('no');
                    $cleanPost['carr'] = $this->input->post('carr');
                    $cleanPost['sem'] = $this->input->post('sem');

                    if (!$this->QrModel->insertQr($cleanPost)) {
                        $this->session->set_flashdata('flash_message', 'There was a problem saving the QR, and generate the QR.');
                        redirect(site_url() . 'qr/generateQr');
                    } else {
                        $this->load->view('template/header', $data);
                        $this->load->view('template/navbar', $data);
                        $this->load->view('template/container');
                        $this->load->view('qr/generate_qr', $data, $cleanPost);
                        $this->load->view('template/footer', $data);
                    }
                }
            }
        }
    }

    /**
     * Ver página de historial.
     *
     * @return void
     */
    public function historyQr()
    {
        $data = $this->session->userdata;
        $data['title'] = 'History QR';

        //comprobar el nivel de usuario
        if (empty($data['role'])) {
            redirect(site_url() . 'main/login/');
        }
        $dataLevel = $this->userlevel->checkLevel($data['role']);
        //comprobar el nivel de usuario

        //Cargar el js
        $data['js_to_load'] = array(
            'jquery.dataTables.min.js',
            'dataTables.buttons.min.js',
            'buttons.flash.min.js',
            'jszip.min.js',
            'pdfmake.min.js',
            'vfs_fonts.js',
            'buttons.html5.min.js',
            'buttons.print.min.js',
            'dataTables.bootstrap.min.js',
            'qr/history_qr.js'
        );

        //checa si es administrador o no
        if ($dataLevel == 'is_admin') {
            $this->load->view('template/header', $data);
            $this->load->view('template/navbar', $data);
            $this->load->view('template/container');
            $this->load->view('qr/history_qr', $data);
            $this->load->view('template/footer', $data);
        } else {
            redirect(site_url() . 'main/');
        }
    }

    /**
     * Función eliminar el QR.
     *
     * @return void
     */
    public function deleteHistoryQr($id)
    {
        $data = $this->session->userdata;
        if (empty($data['role'])) {
            redirect(site_url() . 'main/login/');
        }
        $dataLevel = $this->userlevel->checkLevel($data['role']);
        // Comprobar el nivel de usuario

        // Comprobar si es administrador o no
        if ($dataLevel == 'is_admin') {
            $getDelete = $this->QrModel->deleteHistoryQr($id);

            if (!$getDelete) {
                $this->session->set_flashdata('flash_message', 'Error, cant delete the QR!');
            } else {
                $this->session->set_flashdata('success_message', 'Delete QR was successful.');
            }
            redirect(site_url() . 'qr/historyQr/');
        } else {
            redirect(site_url() . 'main/');
        }
    }

    /**
     * Obtener tablas de datos.
     *
     * @return void
     */
    public function dataTableJson()
    {
        echo $this->QrModel->getDataTables();
    }

    /**
     * Funcion hash password.
     *
     * @param $pass
     * @return hash password
     */
    public function hashPassword($pass){
        $this->load->library('password');
        return $this->password->create_hash($pass);
    }

    /**
     * Sube datos desde un archivo csv.
     *
     * @return void
     */
    public function importData()
    {
        $errorMessage = '';
        $errorMessageQr = '';
        $errorArr = array();
        $errorArrQr = array();

        // Extensión de archivo
        $extension = pathinfo($_FILES['import']['name'], PATHINFO_EXTENSION);

        // Si la extensión del archivo es 'csv'
        if(!empty($_FILES['import']['name']) && $extension == 'csv'){

            $fp = fopen($_FILES['import']['tmp_name'],'r');

            // Saltarse la fila del encabezado
            fgetcsv($fp);

            while(($csvData = fgetcsv($fp)) !== FALSE){
                $csvData = array_map('utf8_encode', $csvData);

                // Longitud de columna de fila
                $dataLen = count($csvData);

                //Saltar fila si longitud != 6
                if( !($dataLen == 9) ) {
                    continue;
                }

                // Asignar valor a las variables
                $email = trim($csvData[0]);
                $first_name = trim($csvData[1]);
                $last_name = trim($csvData[2]);
                $no_control = trim($csvData[3]);
                $carrera = trim($csvData[4]);
                $semestre= trim($csvData[5]);
                $canLogin = trim($csvData[8]);
                $name = $first_name . ' ' . $last_name . ' ' . $no_control . ' ' . $carrera . ' ' . $semestre;

                // Insertar datos en la tabla de usuarios
                if($canLogin == 'yes'){

                    // Compruebe si hay algún correo electrónico duplicado
                    if ($this->MainModel->isDuplicate($email)) {
                        $errorArr[] = $email;
                        $str = implode (", ", $errorArr);
                        $errorMessage = '<span style="color:#b80e0e;">But, some data email already exists ( ' . $str . ' )</span>';
                        continue;
                    }

                    $role = trim($csvData[6]);
                    $password = trim($csvData[7]);

                    $hashed = $this->hashPassword($password);

                    $data = array(
                        'email' => $email,
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'no_control' => $no_control,
                        'carrera' => $carrera,
                        'semestre' => $semestre,
                        'role' => $role,
                        'password' => $hashed,
                    );

                    $this->MainModel->addUser($data);
                }

                // Compruebe si hay algún nombre duplicado del código QR
                if ($this->QrModel->isDuplicateQr($name)) {
                    $errorArrQr[] = $name;
                    $strQr = implode (", ", $errorArrQr);
                    $errorMessageQr = '<span style="color:#b80e0e;"> Also, some data name already exists ( ' . $strQr . ' )</span>';
                    continue;
                }

                // Insertar datos en el código QR
                $data = array(
                    'name' => $name,
              
                );

                $this->QrModel->saveFromCsv($data);
            }

            $this->session->set_flashdata('success_message', 'Imported was success! ' . $errorMessage . ' ' . $errorMessageQr);
            redirect(site_url() . 'qr/generateQr');
        }

        $this->session->set_flashdata('flash_message', 'Please select CSV file.');
        redirect(site_url() . 'qr/generateQr');
    }
}
